select asewkt(the_geom) from loadedshp order by gid;

