-- Validate topology
SELECT * from topology.validatetopology('city_data');

